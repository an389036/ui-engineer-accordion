import { Directive, QueryList, TemplateRef } from '@angular/core';
import { TemplateDirective } from '../directive/template.directive';

import { AccordionPanelComponent } from './accordion-panel.component';

@Directive({
  selector: '[uiTemplate]',
})
export class MockTemplateDirective {
  name: string;
  template: TemplateRef<any> = 'mock-template' as any as TemplateRef<any>;

  getName(): string {
    return this.name;
  }
}

describe('AccordianPanelComponent', () => {
  let component: AccordionPanelComponent;

  beforeEach(() => {
    component = new AccordionPanelComponent();
  });

  it('should be defined', () => {
    expect(component).toBeDefined();
  });

  describe('@Input()', () => {
    /* eslint-disable @typescript-eslint/dot-notation */

    describe('isExpanded', () => {
      it('should update _isExpanded if the panel is button is clicked', () => {
        component['_isExpanded'] = false;
        component.isExpanded = true;
        expect(component['_isExpanded']).toBeTrue();
        expect(component.isExpanded).toBeTrue();
      });
    });

    describe('id', () => {
      it('should set _id if the provided id is defined', () => {
        component.id = 'new-mock-id';
        expect(component['_id']).toEqual('new-mock-id');
        expect(component.id).toEqual('Qnew-mock-id');
      });
    });

    /* eslint-enable @typescript-eslint/dot-notation */
  });

  describe('ngAftercontentInit', () => {
    it('should NOT set headerTemplate or contentTemplate if no templates were found', () => {
      setTemplates([]);
      component.ngAfterContentInit();
      expect(component.titleTemplate).toBeUndefined();
      expect(component.contentTemplate).toBeUndefined();
    });

    it('should NOT set headerTemplate or contentTemplate if the correct template types were NOT found', () => {
      setTemplates(['badTemplateName', 'anotherBadTemplateName']);
      component.ngAfterContentInit();
      expect(component.titleTemplate).toBeUndefined();
      expect(component.contentTemplate).toBeUndefined();
    });

    it('should set headerTemplate and contentTemplate if the correct template types were found', () => {
      setTemplates(['panelTitle', 'panelContent']);
      component.ngAfterContentInit();
      expect(component.titleTemplate).toBeDefined();
      expect(component.contentTemplate).toBeDefined();
    });
  });

  describe('toggleContentVisibility', () => {
    it('should emit that the header was clicked', () => {
      spyOn(component.panelHeaderClicked, 'emit').and.stub();
      component.toggleContentVisibility();
      expect(component.panelHeaderClicked.emit).toHaveBeenCalledWith(component);
    });
  });

  /**
   * Helper function to generate templates that are used to display provided templateRef in ng-content.
   *
   * @param templatesTypes the type of templates
   */
  function setTemplates(templatesTypes?: string[]): void {
    const templates: MockTemplateDirective[] = [];

    if (templatesTypes && !!templatesTypes.length) {
      for (const templateName of templatesTypes) {
        const template: MockTemplateDirective = new MockTemplateDirective();
        template.name = templateName;
        templates.push(template);
      }
    }

    component.templates = new QueryList<TemplateDirective>();
    // eslint-disable-next-line @typescript-eslint/dot-notation
    component.templates['_results'] = templates;
  }
});

