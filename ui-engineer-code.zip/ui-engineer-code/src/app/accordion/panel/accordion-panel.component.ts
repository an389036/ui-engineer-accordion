import {
  animate,
  AnimationEvent,
  style,
  transition,
  trigger,
} from '@angular/animations';
import {
  AfterContentInit,
  Component,
  ContentChildren,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  QueryList,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { TemplateDirective } from '../directive/template.directive';

/**
 * ACCORDION PANEL COMPONENT
 *
 * The Accordion Panel Component consists of a title and content. The plus icon is used to toggle the visibility of the
 * content.
 */
@Component({
  selector: 'app-accordion-panel',
  templateUrl: './accordion-panel.component.html',
  styleUrls: ['./accordion-panel.component.scss'],
  animations: [
    trigger('inOutAnimation', [
      transition(':enter', [
        style({ height: 0 }),
        animate('350ms ease-out', style({ height: '*', opacity: 1, visibility: 'visible' })),
      ]),
      transition(':leave', [
        style({ height: '*' }),
        animate('250ms ease-in', style({ height: 0, opacity: 0, visibility: 'hidden' })),
      ]),
    ]),
  ],
})
export class AccordionPanelComponent implements AfterContentInit {

  @ViewChild('panelContentContainer') panelContentContainer: ElementRef;
  /*
   * When an panel header title button is clicked, emit an event containing information about this component.
   */
  @Output()
  panelHeaderClicked: EventEmitter<AccordionPanelComponent> = new EventEmitter<AccordionPanelComponent>();

  /**
   * When the isExpanded input is updated (with a new value), emit an event that the panel content has either been expanded or collapsed.
   */
  @Output()
  panelContentVisibilityChanged: EventEmitter<AccordionPanelComponent> = new EventEmitter<AccordionPanelComponent>();

  // tslint:disable-next-line:variable-name
  private _isExpanded: boolean;
  @Input()
  set isExpanded(isExpanded: boolean) {
    this._isExpanded = isExpanded;
  }

  get isExpanded(): boolean {
    return this._isExpanded;
  }

  private _id: string;
  @Input()
  set id(id: string) {
    this._id = id || this._id;
  }
  get id(): string {
    return `Q${this._id}`;
  }

  @ContentChildren(TemplateDirective) templates!: QueryList<TemplateDirective>;

  private _titleTemplate: TemplateRef<any>;
  get titleTemplate(): TemplateRef<any> {
    return this._titleTemplate;
  }

  private _contentTemplate: TemplateRef<any>;
  get contentTemplate(): TemplateRef<any> {
    return this._contentTemplate;
  }

  ngAfterContentInit(): void {
    this.templates.forEach((item: TemplateDirective) => {
      const name: string = item.getName();

      if (name === 'panelTitle') {
        this._titleTemplate = item.template;
      }

      if (name === 'panelContent') {
        this._contentTemplate = item.template;
      }
    });
  }

  toggleContentVisibility(): void {
    this.panelHeaderClicked.emit(this);
  }

  toggleOverflow(event: AnimationEvent): void {}
}
