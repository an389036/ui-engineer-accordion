import { QueryList } from '@angular/core';

import { AccordionComponent } from './accordion.component';
import { AccordionPanelComponent } from './panel/accordion-panel.component';

describe('TabviewComponent', () => {
  let component: AccordionComponent;

  beforeEach(() => {
    component = new AccordionComponent();
  });

  it('should be defined', () => {
    expect(component).toBeTruthy();
  });

  describe('@ContentChildren', () => {
    describe('panels', () => {
      it('should set _panels and call updatePanelsMaxContentHeight() and subscribeToPanelChanges()', () => {
        spyOn(component, 'subscribeToPanelChanges').and.stub();
        setPanels(2);
        // eslint-disable-next-line @typescript-eslint/dot-notation
        expect(component['_panels']).toBeTruthy();
        expect(component.panels).toBeTruthy();
        expect(component.panels.toArray().length).toEqual(2);
        expect(component.subscribeToPanelChanges).toHaveBeenCalled();
      });
    });
  });

  describe('subscribeToPanelChanges()', () => {

    it('should update the visibility of panels based on what the states.', () => {
      spyOn(component, 'togglePanelContentVisibility').and.callThrough();

      setPanels(2);
      component.subscribeToPanelChanges();

      component.panels.toArray()[0].isExpanded = false;
      component.panels.toArray()[1].isExpanded = false;
      expect(component.togglePanelContentVisibility).not.toHaveBeenCalled();

      component.panels.toArray()[0].panelHeaderClicked.emit(component.panels.toArray()[0]);
      component.panels.toArray()[1].panelHeaderClicked.emit(component.panels.toArray()[1]);
      expect(component.togglePanelContentVisibility).toHaveBeenCalled();
    });
  });

  describe('togglePanelContentVisibility()', () => {
    it ('should not do anything if the provided panel is undefined', () => {
      const panel: AccordionPanelComponent = undefined;
      component.togglePanelContentVisibility(panel);
      expect(panel).toBeFalsy();
    });

    it('should set the isExpanded value of the provided panel', () => {
      const panel: AccordionPanelComponent = new AccordionPanelComponent();
      component.togglePanelContentVisibility(panel);
      expect(panel.isExpanded).toBeTrue();
      component.togglePanelContentVisibility(panel);
      expect(panel.isExpanded).toBeFalse();
    });

    it('should not loop through all the panels if onePanelList is false, the provided panel was collapsed, or there are no panels', () => {
      component.onePanelLimit = false;
      setPanels(2);
      component.panels.toArray()[0].isExpanded = false;
      component.panels.toArray()[1].isExpanded = true;
      component.togglePanelContentVisibility(component.panels.toArray()[0]);
      expect(component.panels.toArray()[1].isExpanded).toBeTruthy();

      component.onePanelLimit = true;
      setPanels(2);
      component.panels.toArray()[0].isExpanded = true;
      component.panels.toArray()[1].isExpanded = true;
      component.togglePanelContentVisibility(component.panels.toArray()[0]);
      expect(component.panels.toArray()[1].isExpanded).toBeTruthy();

      component.onePanelLimit = true;
      component.panels = undefined;
      const panel: AccordionPanelComponent = new AccordionPanelComponent();
      panel.isExpanded = false;
      component.togglePanelContentVisibility(panel);
      expect(component.panels).toBeFalsy();

      component.onePanelLimit = true;
      setPanels(0);
      panel.isExpanded = false;
      component.togglePanelContentVisibility(panel);
      expect(component.panels.toArray()).toEqual([]);
    });

    it('should collapsed all other panels if onePanelList is set', () => {
      component.onePanelLimit = true;
      setPanels(2);
      component.panels.toArray()[0].isExpanded = false;
      component.panels.toArray()[1].isExpanded = true;
      component.togglePanelContentVisibility(component.panels.toArray()[0]);
      expect(component.panels.toArray()[0].isExpanded).toBeTrue();
      expect(component.panels.toArray()[1].isExpanded).toBeFalse();
    });
  });

  /**
   * Helper function that generates panels for component.panels.
   *
   * @param numPanelComponents the number of panels wanted to generated and added to component.panels
   */
  function setPanels(numTabComponents: number = 1): void {
    const panels: AccordionPanelComponent[] = [];

    for (let i = 0; i < numTabComponents; i++) {
      const tab: AccordionPanelComponent = new AccordionPanelComponent();
      panels.push(tab);
    }

    component.panels = new QueryList<AccordionPanelComponent>();
    // eslint-disable-next-line @typescript-eslint/dot-notation
    component.panels['_results'] = panels;
  }
});
