import { ComponentFixture } from '@angular/core/testing';

import { AccordionTestComponent } from './accordion.component.dom.spec';

/**
 * ACCORDION PAGE OBJECT
 *
 * Page object for the app-accordion component.
 * Makes it easier to find and select certain accordion attributes and elements.
 */
export class AccordionComponentPageObject {
  private fixture: ComponentFixture<AccordionTestComponent>;

  constructor(fixture: ComponentFixture<AccordionTestComponent>) {
    this.fixture = fixture;
  }

  /**
   * Gets the "ui-accordion" element.
   *
   * @returns the "ui-accordion" element
   */
  get accordion(): HTMLElement {
    const accordion: HTMLElement = this.fixture.nativeElement.querySelector(
      'app-accordion'
    );
    return accordion;
  }

  /**
   * Gets the outermost container div element.
   *
   * @returns the outermost container div element
   */
  get container(): HTMLElement {
    const accordion: HTMLElement = this.accordion;
    return accordion ? accordion.querySelector('.ui-accordion') : null;
  }

  /**
   * Gets all of the panels within the accordion.
   *
   * @returns all fo the panels within the accordion
   */
  get panels(): NodeListOf<HTMLElement> {
    const accordion: HTMLElement = this.accordion;
    return accordion ? accordion.querySelectorAll('.accordion-panel') : null;
  }

  /**
   * Gets the panel at the provied index.
   *
   * @param index the index of the panel
   * @returns the panel at the provided index
   */
  getPanelAtIndex(index: number): HTMLElement {
    const panels: NodeListOf<HTMLElement> = this.panels;
    return panels ? panels.item(index) : null;
  }

  /**
   * Gets the title button element of the panel at the provied index.
   *
   * @param index the index of the panel
   * @returns the title button element of the panel at the provided index
   */
  getTitleOfPanelAtIndex(index: number): HTMLButtonElement {
    const panel: HTMLElement = this.getPanelAtIndex(index);
    return panel
      ? panel.querySelector('.accordion-panel__header-container-title')
      : null;
  }

  /**
   * Gets the button icon element of the panel at the provided index.
   *
   * @param index the index of the panel
   * @returns the button element of the panel at the provided index
   */
  getButtonOfPanelAtIndex(index: number): HTMLButtonElement {
    const panel: HTMLElement = this.getPanelAtIndex(index);
    return panel
      ? panel.querySelector('.accordion-panel__header-container-icon')
      : null;
  }

  /**
   * Gets the content element of the panel at the provided index.
   *
   * @param index the index of the panel
   * @returns the content element of the panel at the provided index
   */
  getContentOfPanelAtIndex(index: number): HTMLButtonElement {
    const panel: HTMLElement = this.getPanelAtIndex(index);
    return panel
      ? panel.querySelector('.accordion-panel__content-container')
      : null;
  }
}
