import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { TemplateDirective } from './directive/template.directive';
import { AccordionComponent } from './accordion.component';
import { AccordionPanelComponent } from './panel/accordion-panel.component';

@NgModule({
  declarations: [
    AccordionComponent,
    TemplateDirective,
    AccordionPanelComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule
  ],
  exports: [AccordionComponent, AccordionPanelComponent, TemplateDirective]
})
export class AccordionModule { }
