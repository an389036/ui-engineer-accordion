import { Component, ContentChildren, Input, QueryList } from '@angular/core';
import { Subscription } from 'rxjs';
import { AccordionPanelComponent } from './panel/accordion-panel.component';

@Component({
  selector: 'app-accordion',
  template: '<div class="ui-accordion"><ng-content></ng-content></div>',
})
export class AccordionComponent {
  subscriptions: Subscription;

  @Input() onePanelLimit: boolean;

  // tslint:disable-next-line:variable-name
  private _panels!: QueryList<AccordionPanelComponent>;
  @ContentChildren(AccordionPanelComponent)
  set panels(panels: QueryList<AccordionPanelComponent>) {
    this._panels = panels;
    this.subscribeToPanelChanges();
  }

  get panels(): QueryList<AccordionPanelComponent> {
    return this._panels;
  }

  /**
   * First unsubscribe from any active subscriptions.
   * Then, subscribe to each panels' panelHeaderClicked events.
   * When the panelHeaderClicked event is triggered, toggle the content of the provided panel.
   */
  subscribeToPanelChanges(): void {
    if (this.subscriptions) {
      this.subscriptions.unsubscribe();
    }

    if (this.panels) {
      this.panels.forEach((panel: AccordionPanelComponent) => {
        this.subscriptions = panel.panelHeaderClicked.subscribe(
          (p: AccordionPanelComponent) => this.togglePanelContentVisibility(p)
        );
      });
    }
  }

  /**
   * Toggles the visibility of a panel's content.
   * If only one panel is allowed to be expanded at a time, collapse all other panels.
   *
   * @param panel The panel to either be expanded or collapsed.
   */
  togglePanelContentVisibility(panel: AccordionPanelComponent): void {
    if (!!panel) {
      panel.isExpanded = !panel.isExpanded;

      if (
        this.onePanelLimit &&
        panel.isExpanded &&
        !!this.panels &&
        !!this.panels.toArray().length
      ) {
        this.panels.forEach((p: AccordionPanelComponent) => {
          if (p !== panel && p.isExpanded) {
            p.isExpanded = false;
          }
        });
      }
    }
  }
}
