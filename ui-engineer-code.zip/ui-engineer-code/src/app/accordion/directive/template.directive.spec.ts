import { ElementRef, TemplateRef } from '@angular/core';
import { TemplateDirective } from './template.directive';

export class ComponentStubFactory {

  /**
   * Returns an instance of a stub for an Angular element's TemplateRef.
   */
  static getTemplateRefStub(): Partial<TemplateRef<any>> {
    return {
      elementRef: {
        nativeElement: {}
      } as ElementRef,
    };
  }
}

describe('TemplateDirective', () => {
  let directive: TemplateDirective;
  let template: TemplateRef<any>;


  beforeEach(() => {
    template = ComponentStubFactory.getTemplateRefStub() as TemplateRef<any>;
    directive = new TemplateDirective(template);
  });

  describe('getName()', () => {
    it('should return the template name', () => {
      directive.name = 'directive-name';
      expect(directive.getName()).toEqual('directive-name');
    });
  });
});
