import { Directive, Input, TemplateRef } from '@angular/core';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[uiTemplate]'
})
export class TemplateDirective {

  constructor(public template: TemplateRef<any>) { }

  @Input('uiTemplate') name: string;

  getName(): string {
    return this.name;
}

}
