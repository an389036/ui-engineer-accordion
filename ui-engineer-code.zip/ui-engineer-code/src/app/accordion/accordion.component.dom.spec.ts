import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { TemplateDirective } from './directive/template.directive';

import { AccordionComponentPageObject } from './accordion.component.spec.po';
import { AccordionModule } from './accordion.module';

@Component({
  selector: 'app-accordion-test-component',
  template: `
  <app-accordion
    [onePanelLimit]="onePanelLimit">
    <app-accordion-panel
      *ngFor="let panel of panels"
      [id]="panel?.id">
      <ng-template uiTemplate="panelTitle">{{ panel?.question }}</ng-template>
      <ng-template uiTemplate="panelContent">{{ panel?.answer }}</ng-template>
    </app-accordion-panel>
  </app-accordion>
  `,
})
export class AccordionTestComponent {
  onePanelLimit: boolean;
  panels: any[];

  generatePanels(numOfPanels: number = 0): void {
    const panels: any[] = [];

    for (let i = 0; i < numOfPanels; i++) {
      const panelConfig: any = {
        id: i,
        question: `panel title ${i}`,
        answer: `panel content ${i}`,
      };
      panels.push(panelConfig);
    }

    this.panels = panels;
  }
}

describe('AccordionComponent', () => {
  let component: AccordionTestComponent;
  let fixture: ComponentFixture<AccordionTestComponent>;
  let page: AccordionComponentPageObject;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        AccordionTestComponent,
        TemplateDirective
      ],
      imports: [
        AccordionModule,
        NoopAnimationsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(async () => {
    fixture = TestBed.createComponent(AccordionTestComponent);
    component = fixture.componentInstance;
    page = new AccordionComponentPageObject(fixture);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('when the component loads', () => {
    it('should display no panels if none are added', () => {
      component.generatePanels(0);
      fixture.detectChanges();
      expect(page.panels.length).toEqual(0);
    });

    it('should display as many panels as added', () => {
      component.generatePanels(1);
      fixture.detectChanges();
      expect(page.panels.length).toEqual(1);

      component.generatePanels(5);
      fixture.detectChanges();
      expect(page.panels.length).toEqual(5);

      component.generatePanels(10);
      fixture.detectChanges();
      expect(page.panels.length).toEqual(10);
    });
  });

  describe('when the panel button is clicked', () => {
    it('should expand the panel if it is closed', async () => {
      component.generatePanels(1);
      fixture.detectChanges();

      expect(page.panels.length).toEqual(1);
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();

      const iconButton: HTMLButtonElement = page.getButtonOfPanelAtIndex(0);
      expect(iconButton).toBeTruthy();

      // open a closed panel
      iconButton.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeTruthy();

      // close an opened panel
      iconButton.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();
    });

    it('should only expand or collapse the panel that had its button clicked', async () => {
      component.generatePanels(2);
      fixture.detectChanges();

      expect(page.panels.length).toEqual(2);
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(1)).toBeFalsy();

      const iconButton0: HTMLButtonElement = page.getButtonOfPanelAtIndex(0);
      const iconButton1: HTMLButtonElement = page.getButtonOfPanelAtIndex(1);
      expect(iconButton0).toBeTruthy();
      expect(iconButton1).toBeTruthy();

      // open the first (closed) panel
      iconButton0.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(1)).toBeFalsy();

      // open the second (closed) panel
      iconButton1.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(1)).toBeTruthy();

      // close the first (opened) panel
      iconButton0.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(1)).toBeTruthy();

      // close the second (opened) panel
      iconButton1.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(1)).toBeFalsy();
    });

    it('should close all other panels if onePanelLimit is true', async () => {
      component.generatePanels(3);
      fixture.detectChanges();

      expect(page.panels.length).toEqual(3);
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(1)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(2)).toBeFalsy();

      const iconButton0: HTMLButtonElement = page.getButtonOfPanelAtIndex(0);
      const iconButton1: HTMLButtonElement = page.getButtonOfPanelAtIndex(1);
      const iconButton2: HTMLButtonElement = page.getButtonOfPanelAtIndex(2);
      expect(iconButton0).toBeTruthy();
      expect(iconButton1).toBeTruthy();
      expect(iconButton2).toBeTruthy();

      // Expand all three (3) panels

      iconButton0.click();
      iconButton1.click();
      iconButton2.click();

      fixture.detectChanges();
      await fixture.whenStable();

      expect(page.getContentOfPanelAtIndex(0)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(1)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(2)).toBeTruthy();

      // Set onePanelLimit to true

      component.onePanelLimit = true;
      fixture.detectChanges();

      // Close the first panel, expect no other panels to collapse or expand

      iconButton0.click();

      fixture.detectChanges();
      await fixture.whenStable();

      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(1)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(2)).toBeTruthy();

      // Open the first panel, expect all other panels to collapse

      iconButton0.click();

      fixture.detectChanges();
      await fixture.whenStable();

      expect(page.getContentOfPanelAtIndex(0)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(1)).toBeFalsy();
      expect(page.getContentOfPanelAtIndex(2)).toBeFalsy();
    });
  });

  describe('the panel', () => {
    it('should display the correct title and content', async () => {
      component.generatePanels(1);
      fixture.detectChanges();

      expect(page.panels.length).toEqual(1);
      expect(page.getContentOfPanelAtIndex(0)).toBeFalsy();

      const iconButton: HTMLButtonElement = page.getButtonOfPanelAtIndex(0);
      const title: HTMLElement = page.getTitleOfPanelAtIndex(0);
      expect(iconButton).toBeTruthy();
      expect(title.innerText).toEqual('panel title 0');

      iconButton.click();
      fixture.detectChanges();
      await fixture.whenStable();
      expect(page.getContentOfPanelAtIndex(0)).toBeTruthy();
      expect(page.getContentOfPanelAtIndex(0).innerText).toEqual('panel content 0');
    });
  });

});
