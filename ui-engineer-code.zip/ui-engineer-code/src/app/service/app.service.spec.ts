import { inject, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';

import { AppService } from './app.service';

describe('AppService', () => {
  let service: AppService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [AppService],
    });
    service = TestBed.inject(AppService);
  });

  afterEach(inject(
    [HttpTestingController],
    (httpMock: HttpTestingController) => {
      httpMock.verify();
    }
  ));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('expects service to fetch data with proper sorting', inject(
    [HttpTestingController, AppService],
    (httpMock: HttpTestingController, service: AppService) => {
      // We call the service
      service.getJSON().subscribe((data) => {
        expect(data.data.length).toBe(1);
      });
      // We set the expectations for the HttpClient mock
      const req = httpMock.expectOne('../../assets/supporting-files/faqs.json');
      expect(req.request.method).toEqual('GET');
      // Then we set the fake data to be returned by the mock
      req.flush({
        data: [
          {
            id: '1',
            question: 'abc',
            answer: 'abc',
          },
        ],
      });
    }
  ));
});
