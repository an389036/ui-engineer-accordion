import { Component, OnInit } from '@angular/core';
import { AppService } from './service/app.service';

interface AccordionItem {
  id: string;
  question: string;
  answer: string;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'ui-engineer';
  header = 'HAVE A QUESTION ? WE CAN HELP';
  onePanelLimit: boolean;
  accordionPanels: AccordionItem[];

  constructor(public service: AppService){}

  /**
   * Sets the 'onePanelLimit' value to false
   * and 'accordionPanels' with value fetched from the service.
   */
  ngOnInit(): void{
    this.onePanelLimit = false;
    this.service.getJSON().subscribe((items: AccordionItem[])  => {
      this.accordionPanels = items;
  });
  }
}
