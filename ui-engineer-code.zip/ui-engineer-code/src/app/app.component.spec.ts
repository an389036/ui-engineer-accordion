import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Observable, of } from 'rxjs';

import { AccordionModule } from './accordion/accordion.module';
import { AppComponent } from './app.component';
import { AppService } from './service/app.service';


 // Service stub to mock data from the AppService.
export class AppServiceStub {
  getJSON(): Observable<any> {
    return of([
      {
        id: '1',
        question: 'What vehicles are covered?',
        answer: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
      }]);
  }
}

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<any>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        AccordionModule
      ],
      providers: [{ provide: AppService, useClass: AppServiceStub }],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'ui-engineer'`, () => {
    expect(component.title).toEqual('ui-engineer');
  });

  describe('ngOnInit', () => {
    it('should have accordionPanels populated', async () => {
      spyOn(component.service, 'getJSON').and.callThrough();
      component.ngOnInit();
      expect(component.service.getJSON).toHaveBeenCalled();
      expect(component.accordionPanels.length).toBeGreaterThan(0);
    });
  });

  describe('should render html with the defined header and accordion', () => {
    it('should render header', () => {
      component.ngOnInit();
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      expect(compiled.querySelector('.sub-header').textContent).toContain('HAVE A QUESTION ? WE CAN HELP');
      expect(compiled.querySelector('app-accordion')).toBeDefined();
    });
  });
});
